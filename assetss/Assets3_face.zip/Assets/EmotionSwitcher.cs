using UnityEngine;

public class EmotionSwitcher : MonoBehaviour
{
    public Material neutralMat;
    public Material happyMat;
    public Material sadMat;
    public Material angryMat;

    private Renderer rend;
    private int state = 0;

    void Start()
    {
        rend = GetComponent<Renderer>();
        rend.material = neutralMat;
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            state = (state + 1) % 4;

            switch (state)
            {
                case 0:
                    rend.material = neutralMat;
                    break;
                case 1:
                    rend.material = happyMat;
                    break;
                case 2:
                    rend.material = sadMat;
                    break;
                case 3:
                    rend.material = angryMat;
                    break;
            }
        }
    }
}
