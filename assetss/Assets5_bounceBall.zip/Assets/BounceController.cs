using UnityEngine;

public class BounceController : MonoBehaviour
{
    private Rigidbody rb;
    private float timer = 0f;
    public float stopTime = 5f; // user-defined time in seconds
    private PhysicMaterial bouncyMat;

    void Start()
    {
        rb = GetComponent<Rigidbody>();

        // Get and clone the physics material
        SphereCollider col = GetComponent<SphereCollider>();
        bouncyMat = new PhysicMaterial();
        bouncyMat.bounciness = 1f;
        bouncyMat.bounceCombine = PhysicMaterialCombine.Maximum;
        col.material = bouncyMat;
    }

    void Update()
    {
        if (timer < stopTime)
        {
            timer += Time.deltaTime;

            // Gradually reduce bounciness
            float remaining = Mathf.Clamp01(1 - (timer / stopTime));
            bouncyMat.bounciness = remaining;
        }
        else
        {
            bouncyMat.bounciness = 0f; // Completely stop bouncing
        }
    }
}
