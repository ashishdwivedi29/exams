using UnityEngine;

public class CharacterPlacer : MonoBehaviour
{
    public GameObject character;
    private bool isPlaced = false;

    void Update()
    {
        if (Input.GetMouseButtonDown(0) && !isPlaced)
        {
            character.SetActive(true);
            character.transform.position = new Vector3(0, 1.2f, 0); // top of table
            isPlaced = true;
        if (rotating)
        {
            transform.Rotate(Vector3.up * 100 * Time.deltaTime);
        }
        }
    }
    private bool rotating = false;

    void OnMouseDown()
    {
        rotating = true;
        GetComponent<Renderer>().material.color = Random.ColorHSV();
    }

    void OnMouseUp()
    {
        rotating = false;
    }

    

}


