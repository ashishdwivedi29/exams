using UnityEngine;

public class CandleToggle : MonoBehaviour
{
    public ParticleSystem flame;
    public ParticleSystem smoke;
    public Light candleLight;

    private bool isLit = false;

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (!isLit)
            {
                flame.Play();
                smoke.Play();
                candleLight.enabled = true;
            }
            else
            {
                flame.Stop();
                smoke.Stop();
                candleLight.enabled = false;
            }

            isLit = !isLit;
        }
    }
}
